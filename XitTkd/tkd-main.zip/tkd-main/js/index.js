// Radio Inputs with bi-directional animation
// by simurai

// ps. WebKit only -> uses appearance:none;
// Cross-Browser version by @ryanseddon: http://jsfiddle.net/ryanseddon/FeJT2/