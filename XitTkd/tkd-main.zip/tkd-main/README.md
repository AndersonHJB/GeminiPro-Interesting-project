# 跆拳道比赛简易系统

## 开发者：

- icbug
- AI悦创

首先，前期工作由 AI悦创：[https://www.aiyc.top/](https://www.aiyc.top/)，完成。

**但后期 Plus 完善部分，非常感谢 ICBUG：[https://www.linuxdevblog.cn/](https://www.linuxdevblog.cn/) 的鼎立支持！**